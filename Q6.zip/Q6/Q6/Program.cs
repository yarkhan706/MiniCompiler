﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

public class Program
{
    public static void Main(string[] args)
    {
        List<string> invalidUsernames = new List<string>();
        List<string> validUsernames = new List<string>();
        Dictionary<string, string> usernamePasswordPairs = new Dictionary<string, string>();

        // Part 1: Input Usernames
        Console.WriteLine("Enter usernames (separated by commas): ");
        string input = Console.ReadLine();
        string[] usernames = input.Split(',');

        foreach (var username in usernames)
        {
            string trimmedUsername = username.Trim();
            if (ValidateUsername(trimmedUsername, out string validationMessage))
            {
                validUsernames.Add(trimmedUsername);
                string password = GeneratePassword();
                usernamePasswordPairs.Add(trimmedUsername, password);
                Console.WriteLine($"Validation Result for {trimmedUsername}: {validationMessage}");
                Console.WriteLine($"Generated Password: {password} (Strength: {CheckPasswordStrength(password)})");
            }
            else
            {
                invalidUsernames.Add(trimmedUsername);
                Console.WriteLine($"Validation Result for {trimmedUsername}: {validationMessage}");
            }
        }

        // Save results to file
        SaveResultsToFile(validUsernames, invalidUsernames, usernamePasswordPairs);

        // Part 2: Retry Invalid Usernames
        if (invalidUsernames.Any())
        {
            Console.WriteLine("Do you want to retry invalid usernames? (y/n): ");
            string retryChoice = Console.ReadLine().ToLower();

            if (retryChoice == "y")
            {
                Console.WriteLine("Enter invalid usernames: ");
                string retryInput = Console.ReadLine();
                string[] retryUsernames = retryInput.Split(',');

                foreach (var retryUsername in retryUsernames)
                {
                    string trimmedRetryUsername = retryUsername.Trim();
                    if (ValidateUsername(trimmedRetryUsername, out string retryMessage))
                    {
                        validUsernames.Add(trimmedRetryUsername);
                        string password = GeneratePassword();
                        usernamePasswordPairs.Add(trimmedRetryUsername, password);
                        Console.WriteLine($"Validation Result for {trimmedRetryUsername}: {retryMessage}");
                        Console.WriteLine($"Generated Password: {password} (Strength: {CheckPasswordStrength(password)})");
                    }
                    else
                    {
                        Console.WriteLine($"Validation Result for {trimmedRetryUsername}: {retryMessage}");
                    }
                }

                SaveResultsToFile(validUsernames, invalidUsernames, usernamePasswordPairs);
            }
        }
    }

    // Part 1: Validate Username
    private static bool ValidateUsername(string username, out string validationMessage)
    {
        validationMessage = "";
        string usernamePattern = @"^[a-zA-Z][a-zA-Z0-9_]{4,14}$"; // Start with letter, 5-15 characters, only letters, numbers, and underscores
        Regex regex = new Regex(usernamePattern);

        if (!regex.IsMatch(username))
        {
            if (username.Length < 5 || username.Length > 15)
                validationMessage = "Username length must be between 5 and 15 characters.";
            else if (!char.IsLetter(username[0]))
                validationMessage = "Username must start with a letter.";
            else if (!username.All(c => char.IsLetterOrDigit(c) || c == '_'))
                validationMessage = "Username can only contain letters, digits, and underscores.";
            return false;
        }

        // Count letters, digits, and underscores
        int upperCaseCount = username.Count(char.IsUpper);
        int lowerCaseCount = username.Count(char.IsLower);
        int digitCount = username.Count(char.IsDigit);
        int underscoreCount = username.Count(c => c == '_');

        validationMessage = $"Valid. Letters: {upperCaseCount + lowerCaseCount} (Uppercase: {upperCaseCount}, Lowercase: {lowerCaseCount}), Digits: {digitCount}, Underscores: {underscoreCount}";

        return true;
    }

    // Part 2: Generate Random Password
    private static string GeneratePassword()
    {
        Random random = new Random();
        const string uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string lowercase = "abcdefghijklmnopqrstuvwxyz";
        const string digits = "0123456789";
        const string specialChars = "!@#$%^&*";

        string password = "";

        // Ensure password contains at least 2 uppercase, 2 lowercase, 2 digits, and 2 special characters
        password += GenerateRandomCharacters(uppercase, 2);
        password += GenerateRandomCharacters(lowercase, 2);
        password += GenerateRandomCharacters(digits, 2);
        password += GenerateRandomCharacters(specialChars, 2);

        // Fill the remaining characters (12 total) with any combination of allowed characters
        password += GenerateRandomCharacters(uppercase + lowercase + digits + specialChars, 6);

        return new string(password.OrderBy(c => Guid.NewGuid()).ToArray()); // Shuffle to ensure randomness
    }

    private static string GenerateRandomCharacters(string characters, int count)
    {
        Random random = new Random();
        return new string(Enumerable.Range(0, count).Select(_ => characters[random.Next(characters.Length)]).ToArray());
    }

    // Part 3: Password Strength Check
    private static string CheckPasswordStrength(string password)
    {
        if (password.Length >= 12 && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(char.IsDigit) && password.Any(c => "!@#$%^&*".Contains(c)))
        {
            return "Strong";
        }
        else if (password.Length >= 8)
        {
            return "Medium";
        }
        return "Weak";
    }

    // Part 4: Save Results to File
    private static void SaveResultsToFile(List<string> validUsernames, List<string> invalidUsernames, Dictionary<string, string> usernamePasswordPairs)
    {
        string fileName = "UserDetails.txt";
        using (StreamWriter writer = new StreamWriter(fileName))
        {
            writer.WriteLine("Validation Results:\n");

            foreach (var username in validUsernames)
            {
                writer.WriteLine($"{username} - Valid");
                writer.WriteLine($"Generated Password: {usernamePasswordPairs[username]} (Strength: {CheckPasswordStrength(usernamePasswordPairs[username])})\n");
            }

            foreach (var username in invalidUsernames)
            {
                writer.WriteLine($"{username} - Invalid\n");
            }

            writer.WriteLine("Summary:");
            writer.WriteLine($"Total Usernames: {validUsernames.Count + invalidUsernames.Count}");
            writer.WriteLine($"Valid Usernames: {validUsernames.Count}");
            writer.WriteLine($"Invalid Usernames: {invalidUsernames.Count}");
        }

        Console.WriteLine("Results saved to UserDetails.txt.");
    }
}
